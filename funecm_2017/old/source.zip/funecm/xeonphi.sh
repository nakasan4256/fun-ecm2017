#!/bin/sh

scp /opt/intel/composerxe/lib/mic/libiomp5.so /home/project8/funecm_2016/funecm_xeonphi /home/project8/funecm_2016/.profile  shirase@mic0:/home/shirase/
# scp /opt/intel/composerxe/lib/mic/libiomp5.so /home/project8/funecm/funecm /home/project8/funecm/.profile  mic1:/home/shirase/
