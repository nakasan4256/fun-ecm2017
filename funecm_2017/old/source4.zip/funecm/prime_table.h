#include "gmp.h"

void make_prime_table(int D,int B1,int B2);
