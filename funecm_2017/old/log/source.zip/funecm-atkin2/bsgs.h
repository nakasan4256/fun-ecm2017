#include "gmp.h"
#include "point.h"

void bsgs(mpz_t p,PROJECTIVE_POINT P,const unsigned long int B1,const unsigned long int B2,mpz_t D,const int window_size,const mpz_t N,FILE *fp);

